# iX 2.0 for Telegram

An iX-branded fork of TGExtra for Telegram iOS. The original TGExtra codebase and contributors are retained as the upstream basis; this fork changes the UI/branding and adds an iX floating entry button.

## iX 2.0 branding
- Developer: Abu Marsa — https://t.me/t_9_k
- Development channel: https://t.me/itsabomarsa
- Settings entry: circular iX button in the Telegram UI

## Existing TGExtra features
The fork retains the existing TGExtra feature implementation.

## Build
Use the upstream Theos build environment described by the Makefile/workflows. This source archive has not been compiled in this Linux environment because an iOS SDK/Theos toolchain is required.

## Disclaimer
This is an independent Telegram tweak. It is not affiliated with Telegram. Use at your own risk.

## Build without a Mac

This fork includes `.github/workflows/ix-build.yml`. Upload the project to a GitHub repository, open **Actions → Build iX 2.0 (No Mac Required)**, choose **Run workflow**, and download the generated DEB from the workflow artifacts. GitHub's macOS runner provides the Xcode/iOS build environment remotely.
